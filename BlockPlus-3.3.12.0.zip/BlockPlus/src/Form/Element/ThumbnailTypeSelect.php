<?php declare(strict_types=1);
namespace BlockPlus\Form\Element;

use Laminas\Form\Element\Select;

class ThumbnailTypeSelect extends Select
{
}
