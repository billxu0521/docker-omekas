<?php
namespace Omeka\Api\Exception;

interface ExceptionInterface
{
}
