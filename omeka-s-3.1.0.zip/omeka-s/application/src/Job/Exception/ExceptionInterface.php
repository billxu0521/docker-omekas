<?php
namespace Omeka\Job\Exception;

interface ExceptionInterface
{
}
