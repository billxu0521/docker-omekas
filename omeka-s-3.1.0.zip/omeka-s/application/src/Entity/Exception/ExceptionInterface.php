<?php
namespace Omeka\Entity\Exception;

interface ExceptionInterface
{
}
