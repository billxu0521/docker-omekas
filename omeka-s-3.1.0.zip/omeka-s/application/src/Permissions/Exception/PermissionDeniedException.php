<?php
namespace Omeka\Permissions\Exception;

class PermissionDeniedException extends RuntimeException
{
}
